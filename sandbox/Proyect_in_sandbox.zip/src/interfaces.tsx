//1
export interface CounterState {
  counter: number;
  prev: number;
  changes: number;
}
