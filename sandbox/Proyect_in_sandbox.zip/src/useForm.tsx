import React, { useState, ChangeEvent } from 'react';
import { Formulario } from './Formulario';

// export function useForm<T>(initStage: T) {
export const useForm = <T extends Object>(initStage: T) => {
  const [formulario, setFormulario] = useState(initStage);

  const handleChange = ({ target }: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = target;
    setFormulario({
      ...formulario,
      [name]: value,
    });
  };
  return {
    formulario,
    handleChange,
    ...formulario,
  };
};
